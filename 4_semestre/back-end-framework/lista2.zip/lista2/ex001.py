def concatenacao(string1, string2):
    return string1 + string2 + string2 + string1

print(concatenacao('a', 'b'))