def minEndMax(num1, num2):
    return f'O maximo é {num1} e o minimo é {num2}' if num1 > num2 else f'O maximo é {num2} e o minimo é {num1}'

print(minEndMax(11, 10))