def repeat(word):
    return word*3

print(repeat('olá'))