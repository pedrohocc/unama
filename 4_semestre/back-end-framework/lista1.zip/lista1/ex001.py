def absoluteNumber(num):
    return abs(num)

print(absoluteNumber(-1.5))