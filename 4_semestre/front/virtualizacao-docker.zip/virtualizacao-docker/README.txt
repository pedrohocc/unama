Comando necessario para executar o arquivo compose é:]
- docker-compose up